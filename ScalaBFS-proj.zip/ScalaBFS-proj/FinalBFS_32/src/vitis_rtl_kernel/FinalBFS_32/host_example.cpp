/**********
Copyright (c) 2019, Xilinx, Inc.
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
may be used to endorse or promote products derived from this software
without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**********/

/********************************************************************************************
 * Description:
 *
 * Xilinx's High Bandwidth Memory (HBM)-enabled FPGA are the clear solution for providing
 * massive memory bandwidth within the lowest power, footprint, and system cost envolopes.
 *
 * This example is designed to show a simple use case to understand how to use HBM memory.
 *
 * There are total 32 memory resources referenced as HBM[0:31] by V++ and each has a
 * capacity of storing 256MB of data.
 *
 * This example showcases two use cases to differentiate how efficiently one can use HBM banks.
 *
 * CASE 1:
 *          +-----------+                   +-----------+
 *          |           | ---- Input1 ----> |           |
 *          |           |                   |           |
 *          |   HBM0    | ---- Input2 ----> |   KERNEL  |
 *          |           |                   |           |
 *          |           | <---- Output ---- |           |
 *          +-----------+                   +-----------+
 *
 *  In this case only one HBM Bank, i.e. HBM0, has been used for both the input
 *  vectors and the processed output vector.
 *
 *  CASE 2:
 *          +-----------+                   +-----------+
 *          |           |                   |           |
 *          |   HBM1    | ---- Input1 ----> |           |
 *          |           |                   |           |
 *          +-----------+                   |           |
 *                                          |           |
 *          +-----------+                   |           |
 *          |           |                   |   KERNEL  |
 *          |   HBM2    | ---- Input2 ----> |           |
 *          |           |                   |           |
 *          +-----------+                   |           |
 *                                          |           |
 *          +-----------+                   |           |
 *          |           |                   |           |
 *          |   HBM3    | <---- Output ---- |           |
 *          |           |                   |           |
 *          +-----------+                   +-----------+
 *
 *  In this case three different HBM Banks, i.e. HBM1, HBM2 and HBM3, have been used for input
 *  vectors and the processed output vector.
 *  The banks HBM1 & HBM2 are used for input vectors whereas HBM3 is used for
 *  processed output vector.
 *
 *  The use case highlights significant change in the data transfer throughput (in terms of
 *  Gigabytes per second) when a single and multiple HBM banks are used for the
 *  same application.
 *
 *  *****************************************************************************************/

#include "xcl2.hpp"
#include <algorithm>
#include <iostream>
#include <stdint.h>
#include <stdlib.h>
#include <string>
#include <vector>
using namespace std;
//Number of HBM Banks required
#define MAX_HBM_BANKCOUNT 32
#define BANK_NAME(n) n | XCL_MEM_TOPOLOGY
const int bank[MAX_HBM_BANKCOUNT] = {
    BANK_NAME(0),  BANK_NAME(1),  BANK_NAME(2),  BANK_NAME(3),  BANK_NAME(4),
    BANK_NAME(5),  BANK_NAME(6),  BANK_NAME(7),  BANK_NAME(8),  BANK_NAME(9),
    BANK_NAME(10), BANK_NAME(11), BANK_NAME(12), BANK_NAME(13), BANK_NAME(14),
    BANK_NAME(15), BANK_NAME(16), BANK_NAME(17), BANK_NAME(18), BANK_NAME(19),
    BANK_NAME(20), BANK_NAME(21), BANK_NAME(22), BANK_NAME(23), BANK_NAME(24),
    BANK_NAME(25), BANK_NAME(26), BANK_NAME(27), BANK_NAME(28), BANK_NAME(29),
    BANK_NAME(30), BANK_NAME(31)};




int main(int argc, char *argv[]) {
    if (argc != 6) {
        printf("Usage: %s <XCLBIN> \n", argv[0]);
        return -1;
    }
    cl_int err;
    cl::Context context;
    cl::CommandQueue q;
    cl::Kernel kernel_bfs;
    std::string binaryFile = argv[1];

    // The get_xil_devices will return vector of Xilinx Devices
    auto devices = xcl::get_xil_devices();


    std::string graph = argv[2];//"wiki_vote";//argv[2];//"lj";//"wiki_vote";//"rmat18-8";//argv[2];//

    string bfs_filename;
    cl_uint csr_c_addr;
    cl_uint csr_r_addr;
    cl_uint level_addr;
    cl_uint node_num;
    cl_uint csc_c_addr;
    cl_uint csc_r_addr;
//    cl_uint push_to_pull_level;
//    cl_uint pull_to_push_level;
    cl_uint root = atoi(argv[3]);//1221153;//3;//atoi(argv[3]);//3;//
    cl_uint pipe_num = 32;
    cl_uint ali_num = 8;
    cl_uint push_to_pull_level = atoi(argv[4]);
    cl_uint pull_to_push_level = atoi(argv[5]);
    double result = 0;
    double fre = 0;
    fre = 225;
    unsigned int dataSize = 32*1024*1024;
    FILE *fr;

    if(graph == "wiki_vote"){
        cout << graph << " " << root << endl;
        bfs_filename = "/space1/graph_data/data/Wiki-Vote/32PC/Wiki-Vote_pe_128_ch_";
        csr_c_addr = 260;
        csr_r_addr = 0;
        level_addr = 1837;
        node_num = 8298;
        csc_c_addr = 1227;
        csc_r_addr = 967;
        // push_to_pull_level = 20;
        // pull_to_push_level = 5;
        // root = 3;

        result = 103689;

        // fre = 140;
        // unsigned int dataSize = 256*1024;
        std::string result_file_name = "/space1/lkx-data/result/" + graph +  "-root-"+std::to_string(root)+"-32pc-3.txt";
        fr = fopen(result_file_name.c_str(), "w");
    }
    if(graph == "rmat18-8"){
        cout << graph << " " << root << endl;
        bfs_filename = "/data/lkx-data/data/data/RMAT18-8/32PC/RMAT18-8_pe_128_ch_";
        csr_c_addr = 8193;
        csr_r_addr = 0;
        level_addr = 39650;
        node_num = 262145;
        csc_c_addr = 28018;
        csc_r_addr = 19825;

//        csr_c_addr = 260;
//        csr_r_addr = 0;
//        level_addr = 1837;
//        node_num = 8298;
//        csc_c_addr = 1227;
//        csc_r_addr = 967;
        // push_to_pull_level = 2;
        // pull_to_push_level = 5;
        // root = 3;

        result = 2048538;

        // fre = 140;
        // unsigned int dataSize = 256*1024;
        std::string result_file_name = "/space1/lkx-data/result/" + graph +  "-root-"+std::to_string(root)+"-32pc.txt";
        fr = fopen(result_file_name.c_str(), "w");
    }
    if(graph == "lj"){
        cout << graph << " " << root << endl;
        bfs_filename = "/space1/graph_data/data/LJ/32PC/livejournal_pe_128_ch_";
        csr_c_addr = 151487;
        csr_r_addr = 0;
        level_addr = 1007490;
        node_num = 4847571;
        csc_c_addr = 653068;
        csc_r_addr = 501581;
        // push_to_pull_level = 5;
        // pull_to_push_level = 8;

        result = 68175771;

        // fre = 140;
        // unsigned int dataSize = 256*1024;
        std::string result_file_name = "/space1/lkx-data/result/" + graph +  "-root-"+std::to_string(root)+"-32pc.txt";
        fr = fopen(result_file_name.c_str(), "w");
    }

    if(graph == "pk"){
        cout << graph << " " << root << endl;
        bfs_filename = "/space1/graph_data/data/PK/32PC/pokec_pe_128_ch_";
        csr_c_addr = 51026;
        csr_r_addr = 0;
        level_addr = 392441;
        node_num = 1632804;
        csc_c_addr = 245859;
        csc_r_addr = 194833;
        // push_to_pull_level = 5;
        // pull_to_push_level = 8;

        result = 30159127;

        // fre = 140;
        // unsigned int dataSize = 256*1024;
        std::string result_file_name = "/space1/lkx-data/result/" + graph +  "-root-"+std::to_string(root)+"-32pc.txt";
        fr = fopen(result_file_name.c_str(), "w");
    }

    if(graph == "ho"){
        cout << graph << " " << root << endl;
        bfs_filename = "/space1/graph_data/data/HO/32PC/hollywood_pe_128_ch_";
        csr_c_addr = 35623;
        csr_r_addr = 0;
        level_addr = 1013258;
        node_num = 1139906;
        csc_c_addr = 542252;
        csc_r_addr = 506629;
        // push_to_pull_level = 5;
        // pull_to_push_level = 7;

        result = 113682432;

        // fre = 140;
        // unsigned int dataSize = 256*1024;
        std::string result_file_name = "/space1/lkx-data/result/" + graph +  "-root-"+std::to_string(root)+"-32pc.txt";
        fr = fopen(result_file_name.c_str(), "w");
    }

    if(graph == "or"){
        cout << graph << " " << root << endl;
        bfs_filename = "/space1/graph_data/data/OR/32PC/orkut_pe_128_ch_";
        csr_c_addr = 96020;
        csr_r_addr = 0;
        level_addr = 2128712;
        node_num = 3072627;
        csc_c_addr = 1160376;
        csc_r_addr = 1064356;
        // push_to_pull_level = 4;
        // pull_to_push_level = 88;

        result = 234366517;

        // fre = 140;
        // unsigned int dataSize = 256*1024;
        std::string result_file_name = "/space1/lkx-data/result/" + graph +  "-root-"+std::to_string(root)+"-32pc.txt";
        fr = fopen(result_file_name.c_str(), "w");
    }

    if(graph == "rmat22-16"){
        cout << graph << " " << root << endl;
        bfs_filename = "/space1/graph_data/data/RMAT22-16/32PC/RMAT22-16_pe_128_ch_";
        csr_c_addr = 131072;
        csr_r_addr = 0;
        level_addr = 884104;
        node_num = 4194303;
        csc_c_addr = 573124;
        csc_r_addr = 442052;
        // push_to_pull_level = 2;
        // pull_to_push_level = 5;

        result = 65970498;

        // fre = 140;
        // unsigned int dataSize = 256*1024;
        std::string result_file_name = "/space1/lkx-data/result/" + graph +  "-root-"+std::to_string(root)+"-32pc.txt";
        fr = fopen(result_file_name.c_str(), "w");
    }

    if(graph == "rmat22-32"){
        cout << graph << " " << root << endl;
        bfs_filename = "/space1/graph_data/data/RMAT22-32/32PC/RMAT22-32_pe_128_ch_";
        // csr_c_addr = 131073;
        // csr_r_addr = 0;
        // level_addr = 1431052;
        // node_num = 4194305;
        // csc_c_addr = 846599;
        // csc_r_addr = 715526;
        csr_c_addr = 131073;
        csr_r_addr = 0;
        level_addr = 1465234;
        node_num = 4194305;
        csc_c_addr = 863690;
        csc_r_addr = 732617;
        // push_to_pull_level = 3;
        // pull_to_push_level = 6;

        result = 130484230;

        // fre = 140;
        // unsigned int dataSize = 256*1024;
        std::string result_file_name = "/space1/lkx-data/result/" + graph +  "-root-"+std::to_string(root)+"-32pc.txt";
        fr = fopen(result_file_name.c_str(), "w");
    }

    if(graph == "rmat22-64"){
        cout << graph << " " << root << endl;
        bfs_filename = "/space1/graph_data/data/RMAT22-64/32PC/RMAT22-64_pe_128_ch_";
        csr_c_addr = 131072;
        csr_r_addr = 0;
        level_addr = 2476300;
        node_num = 4194304;
        csc_c_addr = 1369222;
        csc_r_addr = 1238150;
        // push_to_pull_level = 3;
        // pull_to_push_level = 6;

        result = 256614684;

        // fre = 140;
        // unsigned int dataSize = 256*1024;
        std::string result_file_name = "/space1/lkx-data/result/" + graph +  "-root-"+std::to_string(root)+"-32pc.txt";
        fr = fopen(result_file_name.c_str(), "w");
    }

    if(graph == "rmat23-16"){
        cout << graph << " " << root << endl;
        bfs_filename = "/space1/graph_data/data/RMAT23-16/32PC/RMAT23-16_pe_128_ch_";
        csr_c_addr = 262145;
        csr_r_addr = 0;
        level_addr = 1766480;
        node_num = 8388609;
        csc_c_addr = 1145385;
        csc_r_addr = 883240;
        // push_to_pull_level = 3;
        // pull_to_push_level = 6;

        result = 132371305;

        // fre = 140;
        // unsigned int dataSize = 256*1024;
        std::string result_file_name = "/space1/lkx-data/result/" + graph +  "-root-"+std::to_string(root)+"-32pc.txt";
        fr = fopen(result_file_name.c_str(), "w");
    }

    if(graph == "rmat23-32"){
        cout << graph << " " << root << endl;
        bfs_filename = "/space1/graph_data/data/RMAT23-32/32PC/RMAT23-32_pe_128_ch_";
        csr_c_addr = 262144;
        csr_r_addr = 0;
        level_addr = 2871800;
        node_num = 8388608;
        csc_c_addr = 1698044;
        csc_r_addr = 1435900;
        // push_to_pull_level = 3;
        // pull_to_push_level = 6;
        result = 262325095;

        // fre = 140;
        // unsigned int dataSize = 256*1024;
        std::string result_file_name = "/space1/lkx-data/result/" + graph +  "-root-"+std::to_string(root)+"-32pc.txt";
        fr = fopen(result_file_name.c_str(), "w");
    }

    if(graph == "rmat23-64"){
        cout << graph << " " << root << endl;
        bfs_filename = "/space1/graph_data/data/RMAT23-64/32PC/RMAT23-64_pe_128_ch_";
        csr_c_addr = 262145;
        csr_r_addr = 0;
        level_addr = 4884554;
        node_num = 8388609;
        csc_c_addr = 2704422;
        csc_r_addr = 2442277;
        // push_to_pull_level = 3;
        // pull_to_push_level = 6;
        result = 517339837;

        // fre = 140;
        // unsigned int dataSize = 256*1024;
        std::string result_file_name = "/space1/lkx-data/result/" + graph +  "-root-"+std::to_string(root)+"-32pc.txt";
        fr = fopen(result_file_name.c_str(), "w");
    }
        if(graph == "rmat24-16"){
        cout << graph << " " << root << endl;
        bfs_filename = "/space1/graph_data/data/RMAT24-16/32PC/RMAT24-16_pe_128_ch_";
        csr_c_addr = 524289;
        csr_r_addr = 0;
        level_addr = 3486856;
        node_num = 16777217;
        csc_c_addr = 2267717;
        csc_r_addr = 1743428;
        // push_to_pull_level = 2;
        // pull_to_push_level = 5;

        result = 265434106;

        // fre = 140;
        // unsigned int dataSize = 256*1024;
        std::string result_file_name = "/space1/lkx-data/result/" + graph +  "-root-"+std::to_string(root)+"-32pc.txt";
        fr = fopen(result_file_name.c_str(), "w");
    }

    if(graph == "rmat24-32"){
        cout << graph << " " << root << endl;
        bfs_filename = "/space1/graph_data/data/RMAT24-32/32PC/RMAT24-32_direted_pe_128_ch_";
        csr_c_addr = 524289;
        csr_r_addr = 0;
        level_addr = 5694270;
        node_num = 16777216;
        csc_c_addr = 3371424;
        csc_r_addr = 2847135;
        // push_to_pull_level = 2;
        // pull_to_push_level = 5;

        result = 526867347;


        // fre = 140;
        // unsigned int dataSize = 256*1024;
        std::string result_file_name = "/space1/lkx-data/result/" + graph +  "-root-"+std::to_string(root)+"-32pc.txt";
        fr = fopen(result_file_name.c_str(), "w");
    }

    if(graph == "hd"){
        cout << graph << " " << root << endl;
        bfs_filename = "/space1/graph_data/data/HD/32PC/web-hudong_pe_128_ch_";
        csr_c_addr = 62016;
        csr_r_addr = 0;
        level_addr = 297025;
        node_num = 1984484;
        csc_c_addr = 211161;
        csc_r_addr = 149145;
        // push_to_pull_level = 100;
        // pull_to_push_level = 100;

        result = 14869484;

        std::string result_file_name = "/space1/lkx-data/result/" + graph +  "-root-"+std::to_string(root)+"-32pc.txt";
        fr = fopen(result_file_name.c_str(), "w");
    }
    if(graph == "bb"){
        cout << graph << " " << root << endl;
        bfs_filename = "/space1/graph_data/data/BB/32PC/web-baidu-baike_pe_128_ch_";
        csr_c_addr = 66916;
        csr_r_addr = 0;
        level_addr = 346678;
        node_num = 2141300;
        csc_c_addr = 235869;
        csc_r_addr = 168953;
        // push_to_pull_level = 5;
        // pull_to_push_level = 6;

        result = 17794839;

        std::string result_file_name = "/space1/lkx-data/result/" + graph +  "-root-"+std::to_string(root)+"-32pc.txt";
        fr = fopen(result_file_name.c_str(), "w");
    }
    if(graph == "bl"){
        cout << graph << " " << root << endl;
        bfs_filename = "/space1/graph_data/data/BL/32PC/soc-BlogCatalog_pe_128_ch_";
        csr_c_addr = 2775;
        csr_r_addr = 0;
        level_addr = 27972;
        node_num = 88784;
        csc_c_addr = 16144;
        csc_r_addr = 13369;
        // push_to_pull_level = 5;
        // pull_to_push_level = 6;

        result = 2093195;

        std::string result_file_name = "/space1/lkx-data/result/" + graph +  "-root-"+std::to_string(root)+"-32pc.txt";
        fr = fopen(result_file_name.c_str(), "w");
    }
    if(graph == "mg"){
        cout << graph << " " << root << endl;
        bfs_filename = "/space1/graph_data/data/MG/32PC/bio-mouse-gene-2_pe_128_ch_";
        csr_c_addr = 1410;
        csr_r_addr = 0;
        level_addr = 245592;
        node_num = 45101;
        csc_c_addr = 124206;
        csc_r_addr = 122796;
        // push_to_pull_level = 5;
        // pull_to_push_level = 6;

        result = 29343088;

        std::string result_file_name = "/space1/lkx-data/result/" + graph +  "-root-"+std::to_string(root)+"-32pc.txt";
        fr = fopen(result_file_name.c_str(), "w");
    }
    if(graph == "g23"){
        cout << graph << " " << root << endl;
        bfs_filename = "/space1/graph_data/data/G23/32PC/graph500-scale23-ef16_adj_pe_128_ch_";
        csr_c_addr = 143948;
        csr_r_addr = 0;
        level_addr = 2562822;
        node_num = 4606314;
        csc_c_addr = 1425359;
        csc_r_addr = 1281411;
        // push_to_pull_level = 3;
        // pull_to_push_level = 6;

        result = 258501410;

        std::string result_file_name = "/space1/lkx-data/result/" + graph +  "-root-"+std::to_string(root)+"-32pc.txt";
        fr = fopen(result_file_name.c_str(), "w");
    }
    // read_binary_file() command will find the OpenCL binary file created using the
    // V++ compiler load into OpenCL Binary and return pointer to file buffer.
    auto fileBuf = xcl::read_binary_file(binaryFile);

    cl::Program::Binaries bins{{fileBuf.data(), fileBuf.size()}};
    int valid_device = 0;
    std::cout << "*1 "<<devices.size()<<endl;
    for (unsigned int i = 0; i < devices.size(); i++) {
        auto device = devices[i];
        // Creating Context and Command Queue for selected Device
        OCL_CHECK(err, context = cl::Context(device, NULL, NULL, NULL, &err));
        OCL_CHECK(err,
                  q = cl::CommandQueue(
                      context, device, CL_QUEUE_PROFILING_ENABLE, &err));

        std::cout << "Trying to program device[" << i
                  << "]: " << device.getInfo<CL_DEVICE_NAME>() << std::endl;
        std::cout << "*2"<<endl;
        cl::Program program(context, {device}, bins, NULL, &err);
        std::cout << "*3"<<endl;
        if (err != CL_SUCCESS) {
            std::cout << "Failed to program device[" << i
                      << "] with xclbin file!\n";
        } else {
            std::cout << err<<"Device[" << i << "]: program successful!\n";
            OCL_CHECK(err,
                      kernel_bfs = cl::Kernel(program, "FinalBFS_32", &err));
            valid_device++;
            std::cout <<err<< "Device[" << i << "]: kernel_bfs successful!\n";
            break; // we break because we found a valid device
        }
    }
    std::cout << "*4"<<endl;
    if (valid_device == 0) {
        std::cout << "Failed to program any device found, exit!\n";
        exit(EXIT_FAILURE);
    }
    std::cout << "program successful!\n";

    std::vector<cl_long,aligned_allocator<cl_long>> bfs_data[pipe_num];
    std::vector<cl_long,aligned_allocator<cl_long>> bfs_tmp_data[pipe_num];
    for(cl_uint pipe_i = 0; pipe_i < pipe_num; pipe_i++){
      bfs_data[pipe_i].resize(dataSize);
      bfs_tmp_data[pipe_i].resize(dataSize);
    }

    cl_long bfs_data_size = 0;


    string bfs_data_name;
    std::vector <FILE *> fin(pipe_num);
    for(cl_uint i = 0;i<pipe_num;i++){
    	bfs_data_name = bfs_filename + to_string(pipe_num) + "_" +to_string(i) +".bin";
    	fin[i] = fopen(bfs_data_name.c_str(),"rb");
    	fseek(fin[i], 0, SEEK_END);
    	bfs_data_size = ftell(fin[i]) / 8;
    	fseek(fin[i], 0, SEEK_SET);
    	    if (bfs_data_size != fread(&bfs_tmp_data[i][0], sizeof(cl_long), bfs_data_size, fin[i])) {
    	        printf("fread failed");
    	    }
    	    fclose(fin[i]);
    }
    std::cout << "*5"<<endl;
    for (size_t i = 0; i < dataSize; i++) {
    	if(i > ali_num * level_addr /2){
            for(cl_uint pipe_i = 0; pipe_i < pipe_num; pipe_i++){
                bfs_data[pipe_i][i] = 0;
            }
    	}
    	else{
            for(cl_uint pipe_i = 0; pipe_i < pipe_num; pipe_i++){
                bfs_data[pipe_i][i] = bfs_tmp_data[pipe_i][i];
            }
    	}
    }
    printf("bfs_data sucess");
    std::cout << "bfs_data read successful!\n";


    // For Allocating Buffer to specific Global Memory Bank, user has to use cl_mem_ext_ptr_t
    // and provide the Banks
    std::vector<cl_mem_ext_ptr_t> inBufExt(pipe_num);
    std::vector<cl::Buffer> buffer_input(pipe_num);
    for(cl_uint pipe_i = 0; pipe_i < pipe_num; pipe_i++){
        inBufExt[pipe_i].obj = bfs_data[pipe_i].data();
        inBufExt[pipe_i].param = 0;
        inBufExt[pipe_i].flags = bank[pipe_i];
        OCL_CHECK(err, buffer_input[pipe_i]=cl::Buffer(
        	context,
                                     CL_MEM_READ_WRITE |
                                        CL_MEM_EXT_PTR_XILINX |
                                        CL_MEM_USE_HOST_PTR,
                                        sizeof(uint64_t) * dataSize,
                                        &inBufExt[pipe_i],
                                       &err));
        std::cout <<err<<"Buffers"<<pipe_i<<" successful!\n";
    }

    // These commands will allocate memory on the FPGA. The cl::Buffer objects can
    // be used to reference the memory locations on the device.
    //Creating Buffers
    for(cl_uint i = 0;i<pipe_num;i++){
    // Copy input data to Device Global Memory
    OCL_CHECK(err, err = q.enqueueMigrateMemObjects({buffer_input[i]},0/* 0 means from host*/));

    }
    q.finish();
    std::cout << err<<"enqueueMigrateMemObjects successful!\n";


    //Setting the kernel Arguments

    OCL_CHECK(err, err = (kernel_bfs).setArg(0, csr_c_addr));
    OCL_CHECK(err, err = (kernel_bfs).setArg(1, csr_r_addr));
    OCL_CHECK(err, err = (kernel_bfs).setArg(2, csc_c_addr));
    OCL_CHECK(err, err = (kernel_bfs).setArg(3, csc_r_addr));
    OCL_CHECK(err, err = (kernel_bfs).setArg(4, level_addr));
    OCL_CHECK(err, err = (kernel_bfs).setArg(5, node_num));
    OCL_CHECK(err, err = (kernel_bfs).setArg(6, push_to_pull_level));
    OCL_CHECK(err, err = (kernel_bfs).setArg(7, pull_to_push_level));
    OCL_CHECK(err, err = (kernel_bfs).setArg(8, root));
    for(cl_uint pipe_i = 0; pipe_i < pipe_num; pipe_i++){
    	OCL_CHECK(err, err = (kernel_bfs).setArg(9+pipe_i, buffer_input[pipe_i]));
    }


    // time begin
 	double kernel_time_in_sec = 0;
 	std::chrono::duration<double> kernel_time(0);
 	auto kernel_start = std::chrono::high_resolution_clock::now();


    //Start kernel
    OCL_CHECK(err, err = q.enqueueTask(kernel_bfs));
    std::cout << err<< "enqueueTask successful!\n";
    q.finish();


    // time end
    auto kernel_end = std::chrono::high_resolution_clock::now();
    kernel_time = std::chrono::duration<double>(kernel_end - kernel_start);
    kernel_time_in_sec = kernel_time.count();






    // Copy output data to Host Memory
    for(cl_uint i =0;i<pipe_num;i++){
    OCL_CHECK(err,
              err = q.enqueueMigrateMemObjects({buffer_input[i]},
                                               CL_MIGRATE_MEM_OBJECT_HOST));
    }
    q.finish();
    std::cout <<err<< "enqueueMigrateMemObjects successful!\n";
    //Read the level data
    cl_uint node_level = 0;
    cl_uint level_addr_act = level_addr * ali_num /2;
    cl_uint i_act = 0;

// 	for(cl_uint i = 0;i<node_num;i++){
// 		i_act = (cl_uint)i/pipe_num;
// 		node_level = (bfs_data[i%pipe_num][level_addr_act+(cl_uint)i_act/8]>>((i_act%8)*8))&0x00ff;
// 		if(node_level == 0){
// 			fprintf(fr,"level[%d]%d\n",i,0);
// 		}else{
// 			fprintf(fr,"level[%d]%d\n",i,node_level+1);
// 		}
// 	}
// //   for(cl_uint i = 0;i<node_num;i++){
// //   	for(cl_uint j = 0;j<pipe_num;j++){
// //        	fprintf(fd,"level[%d][%d]%ld\n",i,j,bfs_data[j][i+level_addr]+1);
// //    }
// //   }
//    fclose(fr);
//   fclose(fd);
   std::cout << "read data to file successful!\n";
   std::cout << "kernel_count: "<<(bfs_data[0][0] & 0xffffffff) <<endl;
   std::cout << "kernel time in second is: " << kernel_time_in_sec << std::endl;

   double kernel_count_in_sec = bfs_data[0][0] &0xffffffff;
   int level = ((bfs_data[0][0] >> 32)&0xffffffff);
   //kyle

   result /= (1000 / fre);            // to KB
   result /= kernel_count_in_sec; // to GBps
   std::cout << "THROUGHPUT = " << result << " GTep/s" << std::endl;
   std::cout << "level = " << level << std::endl;


   return EXIT_SUCCESS;

}
