// This is a generated file. Use and modify at your own risk.
////////////////////////////////////////////////////////////////////////////////

//-----------------------------------------------------------------------------
// kernel: FinalBFS_32
//
// Purpose: This is a C-model of the RTL kernel intended to be used for cpu
//          emulation.  It is designed to only be functionally equivalent to
//          the RTL Kernel.
//-----------------------------------------------------------------------------
#define WORD_SIZE 32
#define SHORT_WORD_SIZE 16
#define CHAR_WORD_SIZE 8
// Transfer size and buffer size are in words.
#define TRANSFER_SIZE_BITS WORD_SIZE*4096*8
#define BUFFER_WORD_SIZE 8192
#include <string.h>
#include <stdbool.h>
#include "hls_half.h"
#include "ap_axi_sdata.h"
#include "hls_stream.h"


// Function declaration/Interface pragmas to match RTL Kernel
extern "C" void FinalBFS_32 (
    unsigned int csr_c_addr,
    unsigned int csr_r_addr,
    unsigned int csc_c_addr,
    unsigned int csc_r_addr,
    unsigned int level_addr,
    unsigned int node_num,
    unsigned int push_to_pull_level,
    unsigned int pull_to_push_level,
    int* axi00_ptr0,
    int* axi01_ptr0,
    int* axi02_ptr0,
    int* axi03_ptr0,
    int* axi04_ptr0,
    int* axi05_ptr0,
    int* axi06_ptr0,
    int* axi07_ptr0,
    int* axi08_ptr0,
    int* axi09_ptr0,
    int* axi10_ptr0,
    int* axi11_ptr0,
    int* axi12_ptr0,
    int* axi13_ptr0,
    int* axi14_ptr0,
    int* axi15_ptr0
) {

    #pragma HLS INTERFACE m_axi port=axi00_ptr0 offset=slave bundle=m00_axi
    #pragma HLS INTERFACE m_axi port=axi01_ptr0 offset=slave bundle=m01_axi
    #pragma HLS INTERFACE m_axi port=axi02_ptr0 offset=slave bundle=m02_axi
    #pragma HLS INTERFACE m_axi port=axi03_ptr0 offset=slave bundle=m03_axi
    #pragma HLS INTERFACE m_axi port=axi04_ptr0 offset=slave bundle=m04_axi
    #pragma HLS INTERFACE m_axi port=axi05_ptr0 offset=slave bundle=m05_axi
    #pragma HLS INTERFACE m_axi port=axi06_ptr0 offset=slave bundle=m06_axi
    #pragma HLS INTERFACE m_axi port=axi07_ptr0 offset=slave bundle=m07_axi
    #pragma HLS INTERFACE m_axi port=axi08_ptr0 offset=slave bundle=m08_axi
    #pragma HLS INTERFACE m_axi port=axi09_ptr0 offset=slave bundle=m09_axi
    #pragma HLS INTERFACE m_axi port=axi10_ptr0 offset=slave bundle=m10_axi
    #pragma HLS INTERFACE m_axi port=axi11_ptr0 offset=slave bundle=m11_axi
    #pragma HLS INTERFACE m_axi port=axi12_ptr0 offset=slave bundle=m12_axi
    #pragma HLS INTERFACE m_axi port=axi13_ptr0 offset=slave bundle=m13_axi
    #pragma HLS INTERFACE m_axi port=axi14_ptr0 offset=slave bundle=m14_axi
    #pragma HLS INTERFACE m_axi port=axi15_ptr0 offset=slave bundle=m15_axi
    #pragma HLS INTERFACE s_axilite port=csr_c_addr bundle=control
    #pragma HLS INTERFACE s_axilite port=csr_r_addr bundle=control
    #pragma HLS INTERFACE s_axilite port=csc_c_addr bundle=control
    #pragma HLS INTERFACE s_axilite port=csc_r_addr bundle=control
    #pragma HLS INTERFACE s_axilite port=level_addr bundle=control
    #pragma HLS INTERFACE s_axilite port=node_num bundle=control
    #pragma HLS INTERFACE s_axilite port=push_to_pull_level bundle=control
    #pragma HLS INTERFACE s_axilite port=pull_to_push_level bundle=control
    #pragma HLS INTERFACE s_axilite port=axi00_ptr0 bundle=control
    #pragma HLS INTERFACE s_axilite port=axi01_ptr0 bundle=control
    #pragma HLS INTERFACE s_axilite port=axi02_ptr0 bundle=control
    #pragma HLS INTERFACE s_axilite port=axi03_ptr0 bundle=control
    #pragma HLS INTERFACE s_axilite port=axi04_ptr0 bundle=control
    #pragma HLS INTERFACE s_axilite port=axi05_ptr0 bundle=control
    #pragma HLS INTERFACE s_axilite port=axi06_ptr0 bundle=control
    #pragma HLS INTERFACE s_axilite port=axi07_ptr0 bundle=control
    #pragma HLS INTERFACE s_axilite port=axi08_ptr0 bundle=control
    #pragma HLS INTERFACE s_axilite port=axi09_ptr0 bundle=control
    #pragma HLS INTERFACE s_axilite port=axi10_ptr0 bundle=control
    #pragma HLS INTERFACE s_axilite port=axi11_ptr0 bundle=control
    #pragma HLS INTERFACE s_axilite port=axi12_ptr0 bundle=control
    #pragma HLS INTERFACE s_axilite port=axi13_ptr0 bundle=control
    #pragma HLS INTERFACE s_axilite port=axi14_ptr0 bundle=control
    #pragma HLS INTERFACE s_axilite port=axi15_ptr0 bundle=control
    #pragma HLS INTERFACE s_axilite port=return bundle=control
    #pragma HLS INTERFACE ap_ctrl_hs port=return

// Modify contents below to match the function of the RTL Kernel
    unsigned int data;

    // Create input and output buffers for interface m00_axi
    int m00_axi_input_buffer[BUFFER_WORD_SIZE];
    int m00_axi_output_buffer[BUFFER_WORD_SIZE];


    // length is specified in number of words.
    unsigned int m00_axi_length = 4096;


    // Assign input to a buffer
    memcpy(m00_axi_input_buffer, (int*) axi00_ptr0, m00_axi_length*sizeof(int));

    // Add 1 to input buffer and assign to output buffer.
    for (unsigned int i = 0; i < m00_axi_length; i++) {
      m00_axi_output_buffer[i] = m00_axi_input_buffer[i]  + 1;
    }

    // assign output buffer out to memory
    memcpy((int*) axi00_ptr0, m00_axi_output_buffer, m00_axi_length*sizeof(int));


    // Create input and output buffers for interface m01_axi
    int m01_axi_input_buffer[BUFFER_WORD_SIZE];
    int m01_axi_output_buffer[BUFFER_WORD_SIZE];


    // length is specified in number of words.
    unsigned int m01_axi_length = 4096;


    // Assign input to a buffer
    memcpy(m01_axi_input_buffer, (int*) axi01_ptr0, m01_axi_length*sizeof(int));

    // Add 1 to input buffer and assign to output buffer.
    for (unsigned int i = 0; i < m01_axi_length; i++) {
      m01_axi_output_buffer[i] = m01_axi_input_buffer[i]  + 1;
    }

    // assign output buffer out to memory
    memcpy((int*) axi01_ptr0, m01_axi_output_buffer, m01_axi_length*sizeof(int));


    // Create input and output buffers for interface m02_axi
    int m02_axi_input_buffer[BUFFER_WORD_SIZE];
    int m02_axi_output_buffer[BUFFER_WORD_SIZE];


    // length is specified in number of words.
    unsigned int m02_axi_length = 4096;


    // Assign input to a buffer
    memcpy(m02_axi_input_buffer, (int*) axi02_ptr0, m02_axi_length*sizeof(int));

    // Add 1 to input buffer and assign to output buffer.
    for (unsigned int i = 0; i < m02_axi_length; i++) {
      m02_axi_output_buffer[i] = m02_axi_input_buffer[i]  + 1;
    }

    // assign output buffer out to memory
    memcpy((int*) axi02_ptr0, m02_axi_output_buffer, m02_axi_length*sizeof(int));


    // Create input and output buffers for interface m03_axi
    int m03_axi_input_buffer[BUFFER_WORD_SIZE];
    int m03_axi_output_buffer[BUFFER_WORD_SIZE];


    // length is specified in number of words.
    unsigned int m03_axi_length = 4096;


    // Assign input to a buffer
    memcpy(m03_axi_input_buffer, (int*) axi03_ptr0, m03_axi_length*sizeof(int));

    // Add 1 to input buffer and assign to output buffer.
    for (unsigned int i = 0; i < m03_axi_length; i++) {
      m03_axi_output_buffer[i] = m03_axi_input_buffer[i]  + 1;
    }

    // assign output buffer out to memory
    memcpy((int*) axi03_ptr0, m03_axi_output_buffer, m03_axi_length*sizeof(int));


    // Create input and output buffers for interface m04_axi
    int m04_axi_input_buffer[BUFFER_WORD_SIZE];
    int m04_axi_output_buffer[BUFFER_WORD_SIZE];


    // length is specified in number of words.
    unsigned int m04_axi_length = 4096;


    // Assign input to a buffer
    memcpy(m04_axi_input_buffer, (int*) axi04_ptr0, m04_axi_length*sizeof(int));

    // Add 1 to input buffer and assign to output buffer.
    for (unsigned int i = 0; i < m04_axi_length; i++) {
      m04_axi_output_buffer[i] = m04_axi_input_buffer[i]  + 1;
    }

    // assign output buffer out to memory
    memcpy((int*) axi04_ptr0, m04_axi_output_buffer, m04_axi_length*sizeof(int));


    // Create input and output buffers for interface m05_axi
    int m05_axi_input_buffer[BUFFER_WORD_SIZE];
    int m05_axi_output_buffer[BUFFER_WORD_SIZE];


    // length is specified in number of words.
    unsigned int m05_axi_length = 4096;


    // Assign input to a buffer
    memcpy(m05_axi_input_buffer, (int*) axi05_ptr0, m05_axi_length*sizeof(int));

    // Add 1 to input buffer and assign to output buffer.
    for (unsigned int i = 0; i < m05_axi_length; i++) {
      m05_axi_output_buffer[i] = m05_axi_input_buffer[i]  + 1;
    }

    // assign output buffer out to memory
    memcpy((int*) axi05_ptr0, m05_axi_output_buffer, m05_axi_length*sizeof(int));


    // Create input and output buffers for interface m06_axi
    int m06_axi_input_buffer[BUFFER_WORD_SIZE];
    int m06_axi_output_buffer[BUFFER_WORD_SIZE];


    // length is specified in number of words.
    unsigned int m06_axi_length = 4096;


    // Assign input to a buffer
    memcpy(m06_axi_input_buffer, (int*) axi06_ptr0, m06_axi_length*sizeof(int));

    // Add 1 to input buffer and assign to output buffer.
    for (unsigned int i = 0; i < m06_axi_length; i++) {
      m06_axi_output_buffer[i] = m06_axi_input_buffer[i]  + 1;
    }

    // assign output buffer out to memory
    memcpy((int*) axi06_ptr0, m06_axi_output_buffer, m06_axi_length*sizeof(int));


    // Create input and output buffers for interface m07_axi
    int m07_axi_input_buffer[BUFFER_WORD_SIZE];
    int m07_axi_output_buffer[BUFFER_WORD_SIZE];


    // length is specified in number of words.
    unsigned int m07_axi_length = 4096;


    // Assign input to a buffer
    memcpy(m07_axi_input_buffer, (int*) axi07_ptr0, m07_axi_length*sizeof(int));

    // Add 1 to input buffer and assign to output buffer.
    for (unsigned int i = 0; i < m07_axi_length; i++) {
      m07_axi_output_buffer[i] = m07_axi_input_buffer[i]  + 1;
    }

    // assign output buffer out to memory
    memcpy((int*) axi07_ptr0, m07_axi_output_buffer, m07_axi_length*sizeof(int));


    // Create input and output buffers for interface m08_axi
    int m08_axi_input_buffer[BUFFER_WORD_SIZE];
    int m08_axi_output_buffer[BUFFER_WORD_SIZE];


    // length is specified in number of words.
    unsigned int m08_axi_length = 4096;


    // Assign input to a buffer
    memcpy(m08_axi_input_buffer, (int*) axi08_ptr0, m08_axi_length*sizeof(int));

    // Add 1 to input buffer and assign to output buffer.
    for (unsigned int i = 0; i < m08_axi_length; i++) {
      m08_axi_output_buffer[i] = m08_axi_input_buffer[i]  + 1;
    }

    // assign output buffer out to memory
    memcpy((int*) axi08_ptr0, m08_axi_output_buffer, m08_axi_length*sizeof(int));


    // Create input and output buffers for interface m09_axi
    int m09_axi_input_buffer[BUFFER_WORD_SIZE];
    int m09_axi_output_buffer[BUFFER_WORD_SIZE];


    // length is specified in number of words.
    unsigned int m09_axi_length = 4096;


    // Assign input to a buffer
    memcpy(m09_axi_input_buffer, (int*) axi09_ptr0, m09_axi_length*sizeof(int));

    // Add 1 to input buffer and assign to output buffer.
    for (unsigned int i = 0; i < m09_axi_length; i++) {
      m09_axi_output_buffer[i] = m09_axi_input_buffer[i]  + 1;
    }

    // assign output buffer out to memory
    memcpy((int*) axi09_ptr0, m09_axi_output_buffer, m09_axi_length*sizeof(int));


    // Create input and output buffers for interface m10_axi
    int m10_axi_input_buffer[BUFFER_WORD_SIZE];
    int m10_axi_output_buffer[BUFFER_WORD_SIZE];


    // length is specified in number of words.
    unsigned int m10_axi_length = 4096;


    // Assign input to a buffer
    memcpy(m10_axi_input_buffer, (int*) axi10_ptr0, m10_axi_length*sizeof(int));

    // Add 1 to input buffer and assign to output buffer.
    for (unsigned int i = 0; i < m10_axi_length; i++) {
      m10_axi_output_buffer[i] = m10_axi_input_buffer[i]  + 1;
    }

    // assign output buffer out to memory
    memcpy((int*) axi10_ptr0, m10_axi_output_buffer, m10_axi_length*sizeof(int));


    // Create input and output buffers for interface m11_axi
    int m11_axi_input_buffer[BUFFER_WORD_SIZE];
    int m11_axi_output_buffer[BUFFER_WORD_SIZE];


    // length is specified in number of words.
    unsigned int m11_axi_length = 4096;


    // Assign input to a buffer
    memcpy(m11_axi_input_buffer, (int*) axi11_ptr0, m11_axi_length*sizeof(int));

    // Add 1 to input buffer and assign to output buffer.
    for (unsigned int i = 0; i < m11_axi_length; i++) {
      m11_axi_output_buffer[i] = m11_axi_input_buffer[i]  + 1;
    }

    // assign output buffer out to memory
    memcpy((int*) axi11_ptr0, m11_axi_output_buffer, m11_axi_length*sizeof(int));


    // Create input and output buffers for interface m12_axi
    int m12_axi_input_buffer[BUFFER_WORD_SIZE];
    int m12_axi_output_buffer[BUFFER_WORD_SIZE];


    // length is specified in number of words.
    unsigned int m12_axi_length = 4096;


    // Assign input to a buffer
    memcpy(m12_axi_input_buffer, (int*) axi12_ptr0, m12_axi_length*sizeof(int));

    // Add 1 to input buffer and assign to output buffer.
    for (unsigned int i = 0; i < m12_axi_length; i++) {
      m12_axi_output_buffer[i] = m12_axi_input_buffer[i]  + 1;
    }

    // assign output buffer out to memory
    memcpy((int*) axi12_ptr0, m12_axi_output_buffer, m12_axi_length*sizeof(int));


    // Create input and output buffers for interface m13_axi
    int m13_axi_input_buffer[BUFFER_WORD_SIZE];
    int m13_axi_output_buffer[BUFFER_WORD_SIZE];


    // length is specified in number of words.
    unsigned int m13_axi_length = 4096;


    // Assign input to a buffer
    memcpy(m13_axi_input_buffer, (int*) axi13_ptr0, m13_axi_length*sizeof(int));

    // Add 1 to input buffer and assign to output buffer.
    for (unsigned int i = 0; i < m13_axi_length; i++) {
      m13_axi_output_buffer[i] = m13_axi_input_buffer[i]  + 1;
    }

    // assign output buffer out to memory
    memcpy((int*) axi13_ptr0, m13_axi_output_buffer, m13_axi_length*sizeof(int));


    // Create input and output buffers for interface m14_axi
    int m14_axi_input_buffer[BUFFER_WORD_SIZE];
    int m14_axi_output_buffer[BUFFER_WORD_SIZE];


    // length is specified in number of words.
    unsigned int m14_axi_length = 4096;


    // Assign input to a buffer
    memcpy(m14_axi_input_buffer, (int*) axi14_ptr0, m14_axi_length*sizeof(int));

    // Add 1 to input buffer and assign to output buffer.
    for (unsigned int i = 0; i < m14_axi_length; i++) {
      m14_axi_output_buffer[i] = m14_axi_input_buffer[i]  + 1;
    }

    // assign output buffer out to memory
    memcpy((int*) axi14_ptr0, m14_axi_output_buffer, m14_axi_length*sizeof(int));


    // Create input and output buffers for interface m15_axi
    int m15_axi_input_buffer[BUFFER_WORD_SIZE];
    int m15_axi_output_buffer[BUFFER_WORD_SIZE];


    // length is specified in number of words.
    unsigned int m15_axi_length = 4096;


    // Assign input to a buffer
    memcpy(m15_axi_input_buffer, (int*) axi15_ptr0, m15_axi_length*sizeof(int));

    // Add 1 to input buffer and assign to output buffer.
    for (unsigned int i = 0; i < m15_axi_length; i++) {
      m15_axi_output_buffer[i] = m15_axi_input_buffer[i]  + 1;
    }

    // assign output buffer out to memory
    memcpy((int*) axi15_ptr0, m15_axi_output_buffer, m15_axi_length*sizeof(int));


}

