// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xfinalbfs_32.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XFinalbfs_32_CfgInitialize(XFinalbfs_32 *InstancePtr, XFinalbfs_32_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XFinalbfs_32_Start(XFinalbfs_32 *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFinalbfs_32_ReadReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AP_CTRL) & 0x80;
    XFinalbfs_32_WriteReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XFinalbfs_32_IsDone(XFinalbfs_32 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFinalbfs_32_ReadReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XFinalbfs_32_IsIdle(XFinalbfs_32 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFinalbfs_32_ReadReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XFinalbfs_32_IsReady(XFinalbfs_32 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFinalbfs_32_ReadReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XFinalbfs_32_EnableAutoRestart(XFinalbfs_32 *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFinalbfs_32_WriteReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XFinalbfs_32_DisableAutoRestart(XFinalbfs_32 *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFinalbfs_32_WriteReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AP_CTRL, 0);
}

void XFinalbfs_32_Set_csr_c_addr(XFinalbfs_32 *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFinalbfs_32_WriteReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_CSR_C_ADDR_DATA, Data);
}

u32 XFinalbfs_32_Get_csr_c_addr(XFinalbfs_32 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFinalbfs_32_ReadReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_CSR_C_ADDR_DATA);
    return Data;
}

void XFinalbfs_32_Set_csr_r_addr(XFinalbfs_32 *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFinalbfs_32_WriteReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_CSR_R_ADDR_DATA, Data);
}

u32 XFinalbfs_32_Get_csr_r_addr(XFinalbfs_32 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFinalbfs_32_ReadReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_CSR_R_ADDR_DATA);
    return Data;
}

void XFinalbfs_32_Set_csc_c_addr(XFinalbfs_32 *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFinalbfs_32_WriteReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_CSC_C_ADDR_DATA, Data);
}

u32 XFinalbfs_32_Get_csc_c_addr(XFinalbfs_32 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFinalbfs_32_ReadReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_CSC_C_ADDR_DATA);
    return Data;
}

void XFinalbfs_32_Set_csc_r_addr(XFinalbfs_32 *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFinalbfs_32_WriteReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_CSC_R_ADDR_DATA, Data);
}

u32 XFinalbfs_32_Get_csc_r_addr(XFinalbfs_32 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFinalbfs_32_ReadReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_CSC_R_ADDR_DATA);
    return Data;
}

void XFinalbfs_32_Set_level_addr(XFinalbfs_32 *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFinalbfs_32_WriteReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_LEVEL_ADDR_DATA, Data);
}

u32 XFinalbfs_32_Get_level_addr(XFinalbfs_32 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFinalbfs_32_ReadReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_LEVEL_ADDR_DATA);
    return Data;
}

void XFinalbfs_32_Set_node_num(XFinalbfs_32 *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFinalbfs_32_WriteReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_NODE_NUM_DATA, Data);
}

u32 XFinalbfs_32_Get_node_num(XFinalbfs_32 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFinalbfs_32_ReadReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_NODE_NUM_DATA);
    return Data;
}

void XFinalbfs_32_Set_push_to_pull_level(XFinalbfs_32 *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFinalbfs_32_WriteReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_PUSH_TO_PULL_LEVEL_DATA, Data);
}

u32 XFinalbfs_32_Get_push_to_pull_level(XFinalbfs_32 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFinalbfs_32_ReadReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_PUSH_TO_PULL_LEVEL_DATA);
    return Data;
}

void XFinalbfs_32_Set_pull_to_push_level(XFinalbfs_32 *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFinalbfs_32_WriteReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_PULL_TO_PUSH_LEVEL_DATA, Data);
}

u32 XFinalbfs_32_Get_pull_to_push_level(XFinalbfs_32 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFinalbfs_32_ReadReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_PULL_TO_PUSH_LEVEL_DATA);
    return Data;
}

void XFinalbfs_32_Set_axi00_ptr0(XFinalbfs_32 *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFinalbfs_32_WriteReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI00_PTR0_DATA, (u32)(Data));
    XFinalbfs_32_WriteReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI00_PTR0_DATA + 4, (u32)(Data >> 32));
}

u64 XFinalbfs_32_Get_axi00_ptr0(XFinalbfs_32 *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFinalbfs_32_ReadReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI00_PTR0_DATA);
    Data += (u64)XFinalbfs_32_ReadReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI00_PTR0_DATA + 4) << 32;
    return Data;
}

void XFinalbfs_32_Set_axi01_ptr0(XFinalbfs_32 *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFinalbfs_32_WriteReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI01_PTR0_DATA, (u32)(Data));
    XFinalbfs_32_WriteReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI01_PTR0_DATA + 4, (u32)(Data >> 32));
}

u64 XFinalbfs_32_Get_axi01_ptr0(XFinalbfs_32 *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFinalbfs_32_ReadReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI01_PTR0_DATA);
    Data += (u64)XFinalbfs_32_ReadReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI01_PTR0_DATA + 4) << 32;
    return Data;
}

void XFinalbfs_32_Set_axi02_ptr0(XFinalbfs_32 *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFinalbfs_32_WriteReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI02_PTR0_DATA, (u32)(Data));
    XFinalbfs_32_WriteReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI02_PTR0_DATA + 4, (u32)(Data >> 32));
}

u64 XFinalbfs_32_Get_axi02_ptr0(XFinalbfs_32 *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFinalbfs_32_ReadReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI02_PTR0_DATA);
    Data += (u64)XFinalbfs_32_ReadReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI02_PTR0_DATA + 4) << 32;
    return Data;
}

void XFinalbfs_32_Set_axi03_ptr0(XFinalbfs_32 *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFinalbfs_32_WriteReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI03_PTR0_DATA, (u32)(Data));
    XFinalbfs_32_WriteReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI03_PTR0_DATA + 4, (u32)(Data >> 32));
}

u64 XFinalbfs_32_Get_axi03_ptr0(XFinalbfs_32 *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFinalbfs_32_ReadReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI03_PTR0_DATA);
    Data += (u64)XFinalbfs_32_ReadReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI03_PTR0_DATA + 4) << 32;
    return Data;
}

void XFinalbfs_32_Set_axi04_ptr0(XFinalbfs_32 *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFinalbfs_32_WriteReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI04_PTR0_DATA, (u32)(Data));
    XFinalbfs_32_WriteReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI04_PTR0_DATA + 4, (u32)(Data >> 32));
}

u64 XFinalbfs_32_Get_axi04_ptr0(XFinalbfs_32 *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFinalbfs_32_ReadReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI04_PTR0_DATA);
    Data += (u64)XFinalbfs_32_ReadReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI04_PTR0_DATA + 4) << 32;
    return Data;
}

void XFinalbfs_32_Set_axi05_ptr0(XFinalbfs_32 *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFinalbfs_32_WriteReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI05_PTR0_DATA, (u32)(Data));
    XFinalbfs_32_WriteReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI05_PTR0_DATA + 4, (u32)(Data >> 32));
}

u64 XFinalbfs_32_Get_axi05_ptr0(XFinalbfs_32 *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFinalbfs_32_ReadReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI05_PTR0_DATA);
    Data += (u64)XFinalbfs_32_ReadReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI05_PTR0_DATA + 4) << 32;
    return Data;
}

void XFinalbfs_32_Set_axi06_ptr0(XFinalbfs_32 *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFinalbfs_32_WriteReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI06_PTR0_DATA, (u32)(Data));
    XFinalbfs_32_WriteReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI06_PTR0_DATA + 4, (u32)(Data >> 32));
}

u64 XFinalbfs_32_Get_axi06_ptr0(XFinalbfs_32 *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFinalbfs_32_ReadReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI06_PTR0_DATA);
    Data += (u64)XFinalbfs_32_ReadReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI06_PTR0_DATA + 4) << 32;
    return Data;
}

void XFinalbfs_32_Set_axi07_ptr0(XFinalbfs_32 *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFinalbfs_32_WriteReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI07_PTR0_DATA, (u32)(Data));
    XFinalbfs_32_WriteReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI07_PTR0_DATA + 4, (u32)(Data >> 32));
}

u64 XFinalbfs_32_Get_axi07_ptr0(XFinalbfs_32 *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFinalbfs_32_ReadReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI07_PTR0_DATA);
    Data += (u64)XFinalbfs_32_ReadReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI07_PTR0_DATA + 4) << 32;
    return Data;
}

void XFinalbfs_32_Set_axi08_ptr0(XFinalbfs_32 *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFinalbfs_32_WriteReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI08_PTR0_DATA, (u32)(Data));
    XFinalbfs_32_WriteReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI08_PTR0_DATA + 4, (u32)(Data >> 32));
}

u64 XFinalbfs_32_Get_axi08_ptr0(XFinalbfs_32 *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFinalbfs_32_ReadReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI08_PTR0_DATA);
    Data += (u64)XFinalbfs_32_ReadReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI08_PTR0_DATA + 4) << 32;
    return Data;
}

void XFinalbfs_32_Set_axi09_ptr0(XFinalbfs_32 *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFinalbfs_32_WriteReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI09_PTR0_DATA, (u32)(Data));
    XFinalbfs_32_WriteReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI09_PTR0_DATA + 4, (u32)(Data >> 32));
}

u64 XFinalbfs_32_Get_axi09_ptr0(XFinalbfs_32 *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFinalbfs_32_ReadReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI09_PTR0_DATA);
    Data += (u64)XFinalbfs_32_ReadReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI09_PTR0_DATA + 4) << 32;
    return Data;
}

void XFinalbfs_32_Set_axi10_ptr0(XFinalbfs_32 *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFinalbfs_32_WriteReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI10_PTR0_DATA, (u32)(Data));
    XFinalbfs_32_WriteReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI10_PTR0_DATA + 4, (u32)(Data >> 32));
}

u64 XFinalbfs_32_Get_axi10_ptr0(XFinalbfs_32 *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFinalbfs_32_ReadReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI10_PTR0_DATA);
    Data += (u64)XFinalbfs_32_ReadReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI10_PTR0_DATA + 4) << 32;
    return Data;
}

void XFinalbfs_32_Set_axi11_ptr0(XFinalbfs_32 *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFinalbfs_32_WriteReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI11_PTR0_DATA, (u32)(Data));
    XFinalbfs_32_WriteReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI11_PTR0_DATA + 4, (u32)(Data >> 32));
}

u64 XFinalbfs_32_Get_axi11_ptr0(XFinalbfs_32 *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFinalbfs_32_ReadReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI11_PTR0_DATA);
    Data += (u64)XFinalbfs_32_ReadReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI11_PTR0_DATA + 4) << 32;
    return Data;
}

void XFinalbfs_32_Set_axi12_ptr0(XFinalbfs_32 *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFinalbfs_32_WriteReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI12_PTR0_DATA, (u32)(Data));
    XFinalbfs_32_WriteReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI12_PTR0_DATA + 4, (u32)(Data >> 32));
}

u64 XFinalbfs_32_Get_axi12_ptr0(XFinalbfs_32 *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFinalbfs_32_ReadReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI12_PTR0_DATA);
    Data += (u64)XFinalbfs_32_ReadReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI12_PTR0_DATA + 4) << 32;
    return Data;
}

void XFinalbfs_32_Set_axi13_ptr0(XFinalbfs_32 *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFinalbfs_32_WriteReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI13_PTR0_DATA, (u32)(Data));
    XFinalbfs_32_WriteReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI13_PTR0_DATA + 4, (u32)(Data >> 32));
}

u64 XFinalbfs_32_Get_axi13_ptr0(XFinalbfs_32 *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFinalbfs_32_ReadReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI13_PTR0_DATA);
    Data += (u64)XFinalbfs_32_ReadReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI13_PTR0_DATA + 4) << 32;
    return Data;
}

void XFinalbfs_32_Set_axi14_ptr0(XFinalbfs_32 *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFinalbfs_32_WriteReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI14_PTR0_DATA, (u32)(Data));
    XFinalbfs_32_WriteReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI14_PTR0_DATA + 4, (u32)(Data >> 32));
}

u64 XFinalbfs_32_Get_axi14_ptr0(XFinalbfs_32 *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFinalbfs_32_ReadReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI14_PTR0_DATA);
    Data += (u64)XFinalbfs_32_ReadReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI14_PTR0_DATA + 4) << 32;
    return Data;
}

void XFinalbfs_32_Set_axi15_ptr0(XFinalbfs_32 *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFinalbfs_32_WriteReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI15_PTR0_DATA, (u32)(Data));
    XFinalbfs_32_WriteReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI15_PTR0_DATA + 4, (u32)(Data >> 32));
}

u64 XFinalbfs_32_Get_axi15_ptr0(XFinalbfs_32 *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFinalbfs_32_ReadReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI15_PTR0_DATA);
    Data += (u64)XFinalbfs_32_ReadReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_AXI15_PTR0_DATA + 4) << 32;
    return Data;
}

void XFinalbfs_32_InterruptGlobalEnable(XFinalbfs_32 *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFinalbfs_32_WriteReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_GIE, 1);
}

void XFinalbfs_32_InterruptGlobalDisable(XFinalbfs_32 *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFinalbfs_32_WriteReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_GIE, 0);
}

void XFinalbfs_32_InterruptEnable(XFinalbfs_32 *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XFinalbfs_32_ReadReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_IER);
    XFinalbfs_32_WriteReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_IER, Register | Mask);
}

void XFinalbfs_32_InterruptDisable(XFinalbfs_32 *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XFinalbfs_32_ReadReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_IER);
    XFinalbfs_32_WriteReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_IER, Register & (~Mask));
}

void XFinalbfs_32_InterruptClear(XFinalbfs_32 *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFinalbfs_32_WriteReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_ISR, Mask);
}

u32 XFinalbfs_32_InterruptGetEnabled(XFinalbfs_32 *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XFinalbfs_32_ReadReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_IER);
}

u32 XFinalbfs_32_InterruptGetStatus(XFinalbfs_32 *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XFinalbfs_32_ReadReg(InstancePtr->Control_BaseAddress, XFINALBFS_32_CONTROL_ADDR_ISR);
}

